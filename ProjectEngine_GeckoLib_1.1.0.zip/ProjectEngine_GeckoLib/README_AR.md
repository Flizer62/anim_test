# Project Engine — Fabric 1.21.1

محرك محتوى JSON لماينكرافت Java، يحمّل **Items** و**Blocks** و**Entities** من مجلد `Project/` الخارجي. نظام الكائنات يستخدم GeckoLib 4 لعرض موديلات Blockbench وتشغيل الأنيميشن.

## الإصدارات والمتطلبات

- Minecraft Java **1.21.1**
- Fabric Loader 0.16.10 أو أحدث
- Fabric API 0.116.7+1.21.1 أو إصدار متوافق
- Java 21
- GeckoLib **Fabric 1.21.1 — 4.7.3** أو إصدار GeckoLib 4 متوافق
- Gradle 8.10.2 أو أحدث

## تثبيت وتشغيل

1. افتح مجلد السورس كمشروع Gradle في IntelliJ IDEA، أو شغّل `gradle build` باستخدام Java 21 وGradle مثبتين.
2. سيظهر ملف المحرك في `build/libs/` باسم يبدأ بـ `project-engine`.
3. ضع ملف المحرك ونسخة GeckoLib الخاصة بـ Fabric 1.21.1 داخل `.minecraft/mods/`.
4. انسخ مجلد `Project/` الموجود مع هذا المشروع إلى مجلد اللعبة الرئيسي، بجانب `mods/` و`resourcepacks/`.
5. شغّل Minecraft. يتم تسجيل الكائنات أثناء تهيئة المود، ثم يُنشأ Resource Pack تلقائياً وتُفعّل موارده عند دخول العميل.
6. بعد تعديل JSON أو موديلات أو صور أو أنيميشن، أعد تشغيل اللعبة؛ تسجيل Entity Types لا يتم أثناء اللعب.

> GeckoLib اعتماد مطلوب للمحرك، وليس ملفاً يحمّله المحرك ديناميكياً من مسار عشوائي. Fabric يحمّل المودين من `mods/`، ويعلن `fabric.mod.json` أن `geckolib` اعتماد للمحرك. تأكد من استخدام ملف GeckoLib الخاص بـ Fabric وMinecraft 1.21.1.

## بنية مجلدات Project

```text
Project/
├── items/
├── blocks/
├── entity/
│   ├── demo_cube_server.json
│   └── demo_cube_client.json
├── geometry/
│   └── demo_cube.geo.json
├── animations/
│   └── demo_cube.animation.json
└── textures/
    └── entity/
        └── demo_cube.png
```

يظل كل هذا المحتوى خارج ملف JAR؛ المحرك يقرأه من مجلد اللعبة.

## Entities: ملفان لكل كائن

لازم يكون لكل Entity ملفان داخل `Project/entity/`، يحملان نفس قيمة `id`:

- `<name>_server.json` يحتوي `side: "server"`، وخصائص السيرفر.
- `<name>_client.json` يحتوي `side: "client"`، وملفات العرض والأنيميشن.

اسم الملف والـ `side` لازم يتطابقان. لا يتم تسجيل الكائن إذا كان أحد الملفين مفقوداً أو إذا اختلف الـ `id`.

### ملف السيرفر

`Project/entity/demo_cube_server.json`

```json
{
  "id": "project:demo_cube",
  "side": "server",
  "health": 20.0,
  "hitbox": {
    "width": 0.8,
    "height": 0.8
  }
}
```

| الحقل | النوع | المعنى |
|---|---|---|
| `id` | string | معرف Entity بصيغة namespace، مثل `project:demo_cube`. |
| `side` | string | يجب أن يكون `server`. |
| `health` | number | أقصى صحة للكائن، من `0.1` إلى `2048`. |
| `hitbox.width` | number | عرض صندوق التصادم بوحدات Minecraft، من `0.1` إلى `16`. |
| `hitbox.height` | number | ارتفاع صندوق التصادم بوحدات Minecraft، من `0.1` إلى `16`. |

### ملف العميل

`Project/entity/demo_cube_client.json`

```json
{
  "id": "project:demo_cube",
  "side": "client",
  "geometry": "project:demo_cube",
  "texture": "textures/entity/demo_cube.png",
  "animation": "project:demo_cube"
}
```

| الحقل | النوع | المعنى |
|---|---|---|
| `id` | string | نفس `id` الموجود في ملف السيرفر. |
| `side` | string | يجب أن يكون `client`. |
| `geometry` | identifier | يحدد ملف `Project/geometry/<path>.geo.json`. |
| `texture` | path | مسار PNG داخل `Project/textures/`. |
| `animation` | identifier | يحدد ملف `Project/animations/<path>.animation.json`. |

يتم تحويل المعرفات إلى مسارات GeckoLib القياسية داخل Resource Pack المولّد:

- `geometry: "project:demo_cube"` ← `assets/project/geo/demo_cube.geo.json`
- `animation: "project:demo_cube"` ← `assets/project/animations/demo_cube.animation.json`
- `texture: "textures/entity/demo_cube.png"` ← `assets/project/textures/entity/demo_cube.png`

### الأنيميشن الافتراضي

عند إنشاء الكائن، يختار المحرك اسم Animation الأول أبجدياً (حسب الاسم) من كائن `animations` داخل ملف `.animation.json`، ثم يشغّله تلقائياً باستخدام Controller واحد وبشكل Loop، من دون شرط حركة أو AI. لتجنب الالتباس، يفضّل وضع Animation واحد فقط داخل الملف حالياً.

## تجربة الكائن المرفق

المثال `demo_cube` عبارة عن مكعب بسيط بلون واحد، مع دوران وحركة ارتفاع خفيفة متكررة. ليس لديه AI أو Goals أو حركة ذاتية؛ الغرض منه اختبار التسجيل وGeckoLib والـ hitbox والصحة.

بعد تشغيل اللعبة استخدم:

```mcfunction
/summon project:demo_cube ~ ~ ~
```

يجب أن يظهر مكعب الاختبار ويتحرك بالأنيميشن تلقائياً. الصحة `20` والـ hitbox `0.8 × 0.8`.

## ملاحظات Multiplayer

- يجب تثبيت Project Engine وGeckoLib المتوافقين على السيرفر والعميل.
- يجب أن يحتوي السيرفر وكل عميل على ملفات `Project/` متطابقة، خصوصاً تعريفات entities. المحرك لا يرسل ملفات JSON أو الصور أو الموديلات أو الأنيميشن عبر الشبكة.
- ملفات `server` تتحكم في Entity Type والصحة والـ hitbox. ملفات `client` تحدد الموديل والتكستر والأنيميشن.
- Entities الحالية لا تملك AI، أو natural spawning، أو spawn eggs، أو نظام سلوك قابل للبرمجة بعد؛ هذه الإضافة تركز على التسجيل والصحة والـ hitbox والعرض عبر GeckoLib.

## البنية البرمجية

- `JsonContentLoader` — تحميل والتحقق من Items وBlocks.
- `EntityDefinitionLoader` — قراءة ملفات `entity` وتجميع زوج `server/client` بحسب `id`.
- `EntityFactory` و`EntityContentRegistry` — إنشاء وتسجيل Entity Types والـ attributes الافتراضية.
- `ProjectEntity` — كلاس مشترك للكائنات؛ لا يضيف Goals ويعطل AI.
- `ProjectEntityModel` و`ProjectEntityRenderer` — توصيل ملفات Geometry وTexture وAnimation إلى GeckoLib.
- `TextureLoader` — نسخ الملفات الخارجية إلى Resource Pack قياسي بمسارات GeckoLib المعروفة.
- `ProjectContentLoaderClient` — تسجيل Renderer لكل كائن وتفعيل Resource Pack.

الأنظمة الجديدة منفصلة عن نظامي Items وBlocks حتى لا يتغير سلوكهما.
