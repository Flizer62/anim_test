# Project Engine (Fabric 1.21.1)

A JSON-driven content framework for Minecraft Java Edition. It loads **items**, **blocks**, and **entities** from an external `Project/` folder. Custom entities use GeckoLib 4 for Blockbench geometry and animations.

## Target versions

- Minecraft Java **1.21.1**
- Fabric Loader 0.16.10+
- Fabric API 0.116.7+1.21.1 (or a compatible release)
- Java 21
- GeckoLib **Fabric 1.21.1 — 4.7.3** (or a compatible GeckoLib 4 release)
- Gradle 8.10.2+

## Build and install

1. Open this directory as a Gradle project in IntelliJ IDEA, or run `gradle build` with Java 21 and Gradle installed.
2. The engine JAR is created under `build/libs/` with a name beginning `project-engine`.
3. Put the engine JAR and the Fabric 1.21.1 GeckoLib JAR in `.minecraft/mods/`.
4. Copy the included `Project/` folder into the Minecraft game directory, beside `mods/` and `resourcepacks/`.
5. Start the game. Entity types are registered during mod initialization; generated assets are enabled on the client.
6. Restart Minecraft after changing JSON definitions, geometry, textures, or animations. Entity types cannot be registered after the registries freeze.

GeckoLib is a required Fabric mod dependency, not a JAR that Project Engine dynamically loads from an arbitrary path. Fabric loads both mods from `mods/`; the engine declares `geckolib` as a required dependency in `fabric.mod.json`.

## External content layout

```text
Project/
├── items/
├── blocks/
├── entity/
│   ├── demo_cube_server.json
│   └── demo_cube_client.json
├── geometry/
│   └── demo_cube.geo.json
├── animations/
│   └── demo_cube.animation.json
└── textures/
    └── entity/
        └── demo_cube.png
```

All user JSON and assets remain outside the mod JAR.

## Entity definitions

Every entity requires two JSON files in `Project/entity/` with the same `id`:

- `<name>_server.json` must contain `"side": "server"` and server gameplay data.
- `<name>_client.json` must contain `"side": "client"` and client rendering data.

Both files must be present, use the same namespaced `id`, and have a filename suffix matching their `side`.

### Server-side JSON

```json
{
  "id": "project:demo_cube",
  "side": "server",
  "health": 20.0,
  "hitbox": {
    "width": 0.8,
    "height": 0.8
  }
}
```

`health` is the maximum health (0.1–2048). `hitbox.width` and `hitbox.height` are measured in Minecraft blocks (0.1–16).

### Client-side JSON

```json
{
  "id": "project:demo_cube",
  "side": "client",
  "geometry": "project:demo_cube",
  "texture": "textures/entity/demo_cube.png",
  "animation": "project:demo_cube"
}
```

The geometry identifier maps to `Project/geometry/<path>.geo.json`; the animation identifier maps to `Project/animations/<path>.animation.json`; the texture path must point to a PNG inside `Project/textures/`.

The engine copies these into GeckoLib's expected generated resource paths:

- `assets/<namespace>/geo/<path>.geo.json`
- `assets/<namespace>/animations/<path>.animation.json`
- `assets/<entity namespace>/textures/entity/<entity path>.png`

### Default animation

The lexicographically first animation name in the referenced `.animation.json` file is selected automatically and played in a loop as soon as the entity is rendered. No movement condition or AI is required. For predictable behavior, keep one animation in each file for now.

## Included test entity

The supplied `demo_cube` is a one-colour cube with a looping rotation and a small vertical bob. It has no goals or autonomous AI and is included to test registration, health, hitbox and GeckoLib rendering.

Spawn it with:

```mcfunction
/summon project:demo_cube ~ ~ ~
```

## Multiplayer notes

Install compatible versions of Project Engine and GeckoLib on the server and all clients. Keep matching `Project/` definitions and assets on every side; the engine does not synchronize JSON, textures, geometry, or animations over the network. Server JSON controls the entity type, health and hitbox; client JSON selects rendering assets.

Entities currently do not include AI, natural spawning, spawn eggs, or a general behavior scripting system. This implementation focuses on entity registration, max health, hitbox, and GeckoLib rendering/animation.

## Architecture

- `JsonContentLoader` — item and block loading/validation.
- `EntityDefinitionLoader` — validates and pairs entity `server/client` JSON by `id`.
- `EntityFactory` / `EntityContentRegistry` — creates entity types and registers default attributes.
- `ProjectEntity` — shared passive entity class, with no goals and AI disabled.
- `ProjectEntityModel` / `ProjectEntityRenderer` — bridge JSON-selected assets to GeckoLib.
- `TextureLoader` — copies external assets into the generated resource pack.
- `ProjectContentLoaderClient` — registers each renderer and enables the generated resource pack.

Entity code and validation are kept separate from the existing item and block systems.
