package dev.projectloader.model;

import net.minecraft.util.Identifier;

/** Client-only visual assets and the animation that is played continuously by default. */
public record EntityClientDefinition(
        Identifier geometryId,
        Identifier animationId,
        String texturePath,
        String defaultAnimationName
) {
}
