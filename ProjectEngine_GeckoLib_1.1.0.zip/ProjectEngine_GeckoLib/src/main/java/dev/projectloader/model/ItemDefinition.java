package dev.projectloader.model;

import net.minecraft.util.Identifier;

import java.nio.file.Path;

public record ItemDefinition(
        Identifier id,
        String displayName,
        ItemComponents components,
        Path sourceFile
) {
}
