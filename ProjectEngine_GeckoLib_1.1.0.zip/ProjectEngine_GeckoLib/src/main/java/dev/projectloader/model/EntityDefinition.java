package dev.projectloader.model;

import net.minecraft.util.Identifier;

import java.nio.file.Path;

/** Combined entity definition assembled from its matching _server.json and _client.json files. */
public record EntityDefinition(
        Identifier id,
        double health,
        float hitboxWidth,
        float hitboxHeight,
        EntityClientDefinition client,
        Path serverSource,
        Path clientSource
) {
}
