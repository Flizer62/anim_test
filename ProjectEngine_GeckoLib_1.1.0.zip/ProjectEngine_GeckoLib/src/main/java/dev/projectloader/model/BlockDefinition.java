package dev.projectloader.model;

import net.minecraft.util.Identifier;

import java.nio.file.Path;

public record BlockDefinition(
        Identifier id,
        String displayName,
        BlockComponents components,
        Path sourceFile
) {
}
