package dev.projectloader.model;

/**
 * Parsed values for the initial JSON item component set.
 * Nullable values mean that the component was not specified.
 */
public record ItemComponents(
        Double damage,
        Double attackSpeed,
        String texturePath
) {
    public boolean hasCombatAttributes() {
        return damage != null || attackSpeed != null;
    }
}
