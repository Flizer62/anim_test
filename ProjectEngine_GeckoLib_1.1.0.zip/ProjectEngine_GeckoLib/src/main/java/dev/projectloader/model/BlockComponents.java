package dev.projectloader.model;

import net.minecraft.util.Identifier;

/**
 * Parsed values for the block component set. Nullable values mean that the component was not specified
 * (the factory then falls back to a default); {@code texturePath} is always present for a valid block.
 *
 * @param breakTime  seconds needed to break the block by hand in survival mode
 * @param placeSound sound event played when the block is placed
 * @param breakSound sound event played when the block is broken
 * @param texturePath PNG path inside Project/textures/
 */
public record BlockComponents(
        Double breakTime,
        Identifier placeSound,
        Identifier breakSound,
        String texturePath
) {
}
