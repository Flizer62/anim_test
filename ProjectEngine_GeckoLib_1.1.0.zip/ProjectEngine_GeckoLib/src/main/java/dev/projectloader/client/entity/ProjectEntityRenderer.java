package dev.projectloader.client.entity;

import dev.projectloader.entity.ProjectEntity;
import dev.projectloader.model.EntityDefinition;
import net.minecraft.client.render.entity.EntityRendererFactory;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public final class ProjectEntityRenderer extends GeoEntityRenderer<ProjectEntity> {
    public ProjectEntityRenderer(EntityRendererFactory.Context context, EntityDefinition definition) {
        super(context, new ProjectEntityModel(definition));
        this.shadowRadius = 0.25F;
    }
}
