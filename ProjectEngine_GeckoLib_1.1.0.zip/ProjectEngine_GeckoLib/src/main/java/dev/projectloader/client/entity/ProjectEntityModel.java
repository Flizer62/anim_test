package dev.projectloader.client.entity;

import dev.projectloader.entity.ProjectEntity;
import dev.projectloader.model.EntityClientDefinition;
import dev.projectloader.model.EntityDefinition;
import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoRenderer;

/** Resolves the external Project/ files copied into the generated resource pack. */
public final class ProjectEntityModel extends GeoModel<ProjectEntity> {
    private final EntityDefinition definition;

    public ProjectEntityModel(EntityDefinition definition) {
        this.definition = definition;
    }

    @Override
    public Identifier getModelResource(ProjectEntity animatable, GeoRenderer<ProjectEntity> renderer) {
        Identifier geometry = definition.client().geometryId();
        return Identifier.of(geometry.getNamespace(), "geo/" + geometry.getPath() + ".geo.json");
    }

    @Override
    public Identifier getTextureResource(ProjectEntity animatable, GeoRenderer<ProjectEntity> renderer) {
        Identifier entityId = definition.id();
        return Identifier.of(entityId.getNamespace(), "textures/entity/" + entityId.getPath() + ".png");
    }

    @Override
    public Identifier getAnimationResource(ProjectEntity animatable) {
        Identifier animation = definition.client().animationId();
        return Identifier.of(animation.getNamespace(), "animations/" + animation.getPath() + ".animation.json");
    }
}
