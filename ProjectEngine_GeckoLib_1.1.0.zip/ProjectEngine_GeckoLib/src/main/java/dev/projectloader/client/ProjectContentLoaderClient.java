package dev.projectloader.client;

import dev.projectloader.ProjectContentLoader;
import dev.projectloader.client.entity.ProjectEntityRenderers;
import dev.projectloader.texture.TextureLoader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourcePackManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/** Automatically enables the generated resource pack on the client. */
public final class ProjectContentLoaderClient implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("project_content_loader/client");
    private static final String PACK_ID = "file/" + TextureLoader.PACK_FOLDER;

    @Override
    public void onInitializeClient() {
        ProjectEntityRenderers.register(ProjectContentLoader.REGISTERED_ENTITIES);
        ClientLifecycleEvents.CLIENT_STARTED.register(ProjectContentLoaderClient::enableGeneratedPack);
    }

    private static void enableGeneratedPack(MinecraftClient client) {
        try {
            ResourcePackManager manager = client.getResourcePackManager();
            manager.scanPacks();

            if (!manager.hasProfile(PACK_ID)) {
                LOGGER.warn("Generated resource pack '{}' was not discovered; custom item, block and entity assets may be missing", PACK_ID);
                return;
            }

            List<String> enabled = new ArrayList<>(manager.getEnabledIds());
            enabled.remove(PACK_ID);
            enabled.add(PACK_ID); // Put the generated pack last so its assets take priority.
            manager.setEnabledProfiles(enabled);

            client.options.resourcePacks.clear();
            client.options.resourcePacks.addAll(enabled);
            client.options.write();
            client.reloadResources().whenComplete((ignored, throwable) -> {
                if (throwable != null) {
                    LOGGER.error("Could not reload generated Project assets", throwable);
                } else {
                    LOGGER.info("Enabled generated Project item, block and GeckoLib entity assets");
                }
            });
        } catch (RuntimeException exception) {
            LOGGER.error("Could not enable generated resource pack: {}", exception.getMessage(), exception);
        }
    }
}
