package dev.projectloader.client.entity;

import dev.projectloader.registry.RegisteredEntity;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

import java.util.List;

public final class ProjectEntityRenderers {
    private ProjectEntityRenderers() {
    }

    public static void register(List<RegisteredEntity> entities) {
        for (RegisteredEntity registered : entities) {
            EntityRendererRegistry.register(registered.entityType(), context ->
                    new ProjectEntityRenderer(context, registered.definition()));
        }
    }
}
