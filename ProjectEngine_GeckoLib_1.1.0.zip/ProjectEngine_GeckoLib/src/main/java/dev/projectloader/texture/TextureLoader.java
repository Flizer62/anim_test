package dev.projectloader.texture;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.projectloader.model.BlockDefinition;
import dev.projectloader.model.EntityDefinition;
import dev.projectloader.model.ItemDefinition;
import dev.projectloader.registry.RegisteredBlock;
import dev.projectloader.registry.RegisteredEntity;
import dev.projectloader.registry.RegisteredItem;
import dev.projectloader.util.ProjectPaths;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Builds the generated resource pack for JSON-defined items, blocks and GeckoLib entities. */
public final class TextureLoader {
    public static final String PACK_FOLDER = "project_content_loader_generated";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final ProjectPaths paths;
    private final Logger logger;

    public TextureLoader(ProjectPaths paths, Logger logger) {
        this.paths = paths;
        this.logger = logger;
    }

    public Path generateResourcePack(List<RegisteredItem> items, List<RegisteredBlock> blocks, List<RegisteredEntity> entities) throws IOException {
        Path packRoot = paths.gameDirectory().resolve("resourcepacks").resolve(PACK_FOLDER);
        deleteDirectoryIfPresent(packRoot);
        Files.createDirectories(packRoot);

        JsonObject metadata = new JsonObject();
        JsonObject pack = new JsonObject();
        pack.addProperty("pack_format", 34); // Resource pack format for Java 1.21-1.21.1.
        pack.addProperty("description", "Generated JSON items, blocks and GeckoLib entities from Project/");
        metadata.add("pack", pack);
        writeJson(packRoot.resolve("pack.mcmeta"), metadata);

        Map<String, JsonObject> languageFiles = new LinkedHashMap<>();

        for (RegisteredItem registered : items) {
            writeItem(packRoot, registered.definition(), languageFiles);
        }
        for (RegisteredBlock registered : blocks) {
            writeBlock(packRoot, registered.definition(), languageFiles);
        }
        for (RegisteredEntity registered : entities) {
            writeEntityAssets(packRoot, registered.definition(), languageFiles);
        }

        for (Map.Entry<String, JsonObject> entry : languageFiles.entrySet()) {
            Path languageFile = packRoot.resolve("assets").resolve(entry.getKey())
                    .resolve("lang").resolve("en_us.json");
            writeJson(languageFile, entry.getValue());
        }

        logger.info("Generated resource pack at {} ({} item(s), {} block(s), {} entity(s))", packRoot, items.size(), blocks.size(), entities.size());
        return packRoot;
    }

    private void writeItem(Path packRoot, ItemDefinition definition, Map<String, JsonObject> languageFiles) throws IOException {
        Identifier id = definition.id();
        JsonObject language = languageFiles.computeIfAbsent(id.getNamespace(), ignored -> new JsonObject());
        language.addProperty(translationKey("item", id), definition.displayName());

        String texturePath = definition.components().texturePath();
        if (texturePath == null) {
            // Still provide a model; Minecraft will show its missing-texture sprite until one is supplied.
            writeGeneratedModel(packRoot, id, null);
            return;
        }

        copyTexture(packRoot, id, "item", texturePath);
        writeGeneratedModel(packRoot, id, id.getNamespace() + ":item/" + id.getPath());
    }

    /**
     * A block needs four files: the texture, a blockstate pointing at the block model, the block model itself
     * (a plain cube using the texture on every face) and an item model so the BlockItem looks like the block.
     */
    private void writeBlock(Path packRoot, BlockDefinition definition, Map<String, JsonObject> languageFiles) throws IOException {
        Identifier id = definition.id();
        JsonObject language = languageFiles.computeIfAbsent(id.getNamespace(), ignored -> new JsonObject());
        language.addProperty(translationKey("block", id), definition.displayName());
        // A BlockItem uses the block's key; the item key is only a harmless fallback.
        language.addProperty(translationKey("item", id), definition.displayName());

        copyTexture(packRoot, id, "block", definition.components().texturePath());

        String blockModelId = id.getNamespace() + ":block/" + id.getPath();

        JsonObject variant = new JsonObject();
        variant.addProperty("model", blockModelId);
        JsonObject variants = new JsonObject();
        variants.add("", variant);
        JsonObject blockstate = new JsonObject();
        blockstate.add("variants", variants);
        writeJson(assetFile(packRoot, id, "blockstates", id.getPath() + ".json"), blockstate);

        JsonObject textures = new JsonObject();
        textures.addProperty("all", blockModelId);
        JsonObject blockModel = new JsonObject();
        blockModel.addProperty("parent", "minecraft:block/cube_all");
        blockModel.add("textures", textures);
        writeJson(assetFile(packRoot, id, "models/block", id.getPath() + ".json"), blockModel);

        JsonObject itemModel = new JsonObject();
        itemModel.addProperty("parent", blockModelId);
        writeJson(assetFile(packRoot, id, "models/item", id.getPath() + ".json"), itemModel);
    }


    /**
     * GeckoLib reads its usual resource paths. The source files stay external under Project/; this method
     * copies them into the generated pack using the ids from the paired client-side entity JSON.
     */
    private void writeEntityAssets(Path packRoot, EntityDefinition definition,
                                   Map<String, JsonObject> languageFiles) throws IOException {
        Identifier id = definition.id();
        JsonObject language = languageFiles.computeIfAbsent(id.getNamespace(), ignored -> new JsonObject());
        language.addProperty(translationKey("entity", id), humanize(id.getPath()));

        Identifier geometryId = definition.client().geometryId();
        Path geometrySource = paths.resolveGeometryFile(geometryId);
        Path geometryDestination = assetFile(packRoot, geometryId, "geo", geometryId.getPath() + ".geo.json");
        Files.createDirectories(geometryDestination.getParent());
        Files.copy(geometrySource, geometryDestination, StandardCopyOption.REPLACE_EXISTING);

        Identifier animationId = definition.client().animationId();
        Path animationSource = paths.resolveAnimationFile(animationId);
        Path animationDestination = assetFile(packRoot, animationId, "animations",
                animationId.getPath() + ".animation.json");
        Files.createDirectories(animationDestination.getParent());
        Files.copy(animationSource, animationDestination, StandardCopyOption.REPLACE_EXISTING);

        Path sourceTexture = paths.resolveTextureFile(definition.client().texturePath());
        Path destinationTexture = assetFile(packRoot, id, "textures/entity", id.getPath() + ".png");
        Files.createDirectories(destinationTexture.getParent());
        Files.copy(sourceTexture, destinationTexture, StandardCopyOption.REPLACE_EXISTING);
    }

    private static String humanize(String value) {
        String leaf = value.substring(value.lastIndexOf('/') + 1).replace('_', ' ').replace('-', ' ');
        if (leaf.isEmpty()) {
            return value;
        }
        return Character.toUpperCase(leaf.charAt(0)) + leaf.substring(1);
    }

    private void copyTexture(Path packRoot, Identifier id, String folder, String texturePath) throws IOException {
        Path sourceTexture = paths.resolveTextureFile(texturePath);
        Path destinationTexture = assetFile(packRoot, id, "textures/" + folder, id.getPath() + ".png");
        Files.createDirectories(destinationTexture.getParent());
        Files.copy(sourceTexture, destinationTexture, StandardCopyOption.REPLACE_EXISTING);
    }

    private static void writeGeneratedModel(Path packRoot, Identifier itemId, String textureId) throws IOException {
        JsonObject model = new JsonObject();
        model.addProperty("parent", "minecraft:item/generated");
        if (textureId != null) {
            JsonObject textures = new JsonObject();
            textures.addProperty("layer0", textureId);
            model.add("textures", textures);
        }

        writeJson(assetFile(packRoot, itemId, "models/item", itemId.getPath() + ".json"), model);
    }

    private static Path assetFile(Path packRoot, Identifier id, String folder, String fileName) {
        return packRoot.resolve("assets").resolve(id.getNamespace()).resolve(folder).resolve(fileName).normalize();
    }

    private static String translationKey(String type, Identifier id) {
        return type + "." + id.getNamespace() + "." + id.getPath().replace('/', '.');
    }

    private static void writeJson(Path file, JsonObject json) throws IOException {
        Files.createDirectories(file.getParent());
        Files.writeString(file, GSON.toJson(json), StandardCharsets.UTF_8);
    }

    private static void deleteDirectoryIfPresent(Path directory) throws IOException {
        if (!Files.exists(directory)) {
            return;
        }
        List<Path> entries;
        try (var walk = Files.walk(directory)) {
            entries = walk.sorted((a, b) -> b.getNameCount() - a.getNameCount()).toList();
        }
        for (Path entry : entries) {
            Files.deleteIfExists(entry);
        }
    }
}
