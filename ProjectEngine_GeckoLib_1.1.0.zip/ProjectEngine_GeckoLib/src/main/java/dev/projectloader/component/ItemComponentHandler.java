package dev.projectloader.component;

import com.google.gson.JsonElement;

@FunctionalInterface
public interface ItemComponentHandler {
    void apply(JsonElement value, ComponentContext context) throws DefinitionException;
}
