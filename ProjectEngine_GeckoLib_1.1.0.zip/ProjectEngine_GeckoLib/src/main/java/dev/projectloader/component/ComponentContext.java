package dev.projectloader.component;

import dev.projectloader.model.ItemComponents;

/** Mutable context populated by component handlers while validating JSON. */
public final class ComponentContext {
    private Double damage;
    private Double attackSpeed;
    private String texturePath;

    public void setDamage(double damage) {
        this.damage = damage;
    }

    public void setAttackSpeed(double attackSpeed) {
        this.attackSpeed = attackSpeed;
    }

    public void setTexturePath(String texturePath) {
        this.texturePath = texturePath;
    }

    public ItemComponents toComponents() {
        return new ItemComponents(damage, attackSpeed, texturePath);
    }
}
