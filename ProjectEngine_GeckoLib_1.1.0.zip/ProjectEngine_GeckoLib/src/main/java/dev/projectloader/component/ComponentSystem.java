package dev.projectloader.component;

import com.google.gson.JsonElement;
import dev.projectloader.util.ProjectPaths;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registry of JSON component handlers. New item components can be added by
 * registering another handler without changing the JSON loading pipeline.
 */
public final class ComponentSystem {
    private final Map<String, ItemComponentHandler> handlers = new LinkedHashMap<>();

    public ComponentSystem(ProjectPaths paths) {
        register("damage", (value, context) -> {
            double number = ComponentValues.number(value, "damage");
            if (number < 0.0 || number > 2048.0) {
                throw new DefinitionException("components.damage must be between 0 and 2048");
            }
            context.setDamage(number);
        });

        register("attack_speed", (value, context) -> {
            double number = ComponentValues.number(value, "attack_speed");
            if (number <= 0.0 || number > 1024.0) {
                throw new DefinitionException("components.attack_speed must be greater than 0 and at most 1024");
            }
            context.setAttackSpeed(number);
        });

        register("texture", (value, context) -> context.setTexturePath(ComponentValues.texture(value, paths)));
    }

    public void register(String key, ItemComponentHandler handler) {
        if (handlers.putIfAbsent(key, handler) != null) {
            throw new IllegalArgumentException("Component handler already registered: " + key);
        }
    }

    public void applyAll(Map<String, JsonElement> values, ComponentContext context) throws DefinitionException {
        for (Map.Entry<String, JsonElement> entry : values.entrySet()) {
            ItemComponentHandler handler = handlers.get(entry.getKey());
            if (handler == null) {
                throw new DefinitionException("Unknown item component: " + entry.getKey());
            }
            handler.apply(entry.getValue(), context);
        }
    }
}
