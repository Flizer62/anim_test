package dev.projectloader.component;

import com.google.gson.JsonElement;
import dev.projectloader.util.ProjectPaths;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registry of JSON component handlers for blocks. To add a new block component:
 * add a field to {@link BlockComponentContext} and {@link dev.projectloader.model.BlockComponents},
 * register a handler here, and apply the value in {@code BlockFactory}.
 */
public final class BlockComponentSystem {
    /** Upper bound for {@code break_time}, in seconds. */
    public static final double MAX_BREAK_TIME = 3600.0;

    private final Map<String, BlockComponentHandler> handlers = new LinkedHashMap<>();

    public BlockComponentSystem(ProjectPaths paths) {
        register("texture", (value, context) -> context.setTexturePath(ComponentValues.texture(value, paths)));

        register("break_time", (value, context) -> {
            double seconds = ComponentValues.number(value, "break_time");
            if (seconds < 0.0 || seconds > MAX_BREAK_TIME) {
                throw new DefinitionException("components.break_time must be between 0 and " + (int) MAX_BREAK_TIME + " seconds");
            }
            context.setBreakTime(seconds);
        });

        register("place_sound", (value, context) -> context.setPlaceSound(readSound(value, "place_sound")));
        register("break_sound", (value, context) -> context.setBreakSound(readSound(value, "break_sound")));
    }

    public void register(String key, BlockComponentHandler handler) {
        if (handlers.putIfAbsent(key, handler) != null) {
            throw new IllegalArgumentException("Block component handler already registered: " + key);
        }
    }

    public void applyAll(Map<String, JsonElement> values, BlockComponentContext context) throws DefinitionException {
        for (Map.Entry<String, JsonElement> entry : values.entrySet()) {
            BlockComponentHandler handler = handlers.get(entry.getKey());
            if (handler == null) {
                throw new DefinitionException("Unknown block component: " + entry.getKey());
            }
            handler.apply(entry.getValue(), context);
        }
    }

    /**
     * A sound is a sound event id such as "minecraft:block.stone.place". Vanilla ids are checked against the
     * registry so typos are caught; ids from other namespaces are accepted because their owner (another mod or a
     * resource pack) may register them later than this loader runs.
     */
    private static Identifier readSound(JsonElement value, String name) throws DefinitionException {
        String raw = ComponentValues.string(value, name);
        Identifier id = Identifier.tryParse(raw);
        if (id == null) {
            throw new DefinitionException("components." + name + " must be a valid sound id, e.g. minecraft:block.stone.place");
        }
        if ("minecraft".equals(id.getNamespace()) && !Registries.SOUND_EVENT.containsId(id)) {
            throw new DefinitionException("components." + name + ": unknown vanilla sound '" + id + "'");
        }
        return id;
    }
}
