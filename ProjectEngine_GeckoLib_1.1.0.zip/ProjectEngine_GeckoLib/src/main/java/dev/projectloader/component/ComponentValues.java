package dev.projectloader.component;

import com.google.gson.JsonElement;
import dev.projectloader.util.ProjectPaths;

/** Small readers shared by the item and block component handlers. */
public final class ComponentValues {
    private ComponentValues() {
    }

    /** Reads a finite JSON number. {@code name} is the component key, used in error messages. */
    public static double number(JsonElement value, String name) throws DefinitionException {
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new DefinitionException("components." + name + " must be a number");
        }

        double number;
        try {
            number = value.getAsDouble();
        } catch (NumberFormatException exception) {
            throw new DefinitionException("components." + name + " must be a finite number", exception);
        }

        if (!Double.isFinite(number)) {
            throw new DefinitionException("components." + name + " must be a finite number");
        }
        return number;
    }

    /** Reads a non-empty, trimmed JSON string. */
    public static String string(JsonElement value, String name) throws DefinitionException {
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new DefinitionException("components." + name + " must be a string");
        }

        String string = value.getAsString().trim();
        if (string.isEmpty()) {
            throw new DefinitionException("components." + name + " cannot be empty");
        }
        return string;
    }

    /** Reads {@code components.texture} and checks that it points to an existing PNG in Project/textures/. */
    public static String texture(JsonElement value, ProjectPaths paths) throws DefinitionException {
        String texture = string(value, "texture");
        try {
            paths.resolveTextureFile(texture);
        } catch (Exception exception) {
            throw new DefinitionException("Invalid components.texture path: " + exception.getMessage(), exception);
        }
        return texture;
    }
}
