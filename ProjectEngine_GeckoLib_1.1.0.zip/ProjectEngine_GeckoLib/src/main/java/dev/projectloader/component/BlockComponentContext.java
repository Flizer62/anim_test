package dev.projectloader.component;

import dev.projectloader.model.BlockComponents;
import net.minecraft.util.Identifier;

/** Mutable context populated by block component handlers while validating JSON. */
public final class BlockComponentContext {
    private Double breakTime;
    private Identifier placeSound;
    private Identifier breakSound;
    private String texturePath;

    public void setBreakTime(double breakTime) {
        this.breakTime = breakTime;
    }

    public void setPlaceSound(Identifier placeSound) {
        this.placeSound = placeSound;
    }

    public void setBreakSound(Identifier breakSound) {
        this.breakSound = breakSound;
    }

    public void setTexturePath(String texturePath) {
        this.texturePath = texturePath;
    }

    public BlockComponents toComponents() {
        return new BlockComponents(breakTime, placeSound, breakSound, texturePath);
    }
}
