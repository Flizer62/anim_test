package dev.projectloader.component;

import com.google.gson.JsonElement;

@FunctionalInterface
public interface BlockComponentHandler {
    void apply(JsonElement value, BlockComponentContext context) throws DefinitionException;
}
