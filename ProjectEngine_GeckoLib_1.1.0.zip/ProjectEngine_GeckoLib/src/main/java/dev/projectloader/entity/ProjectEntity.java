package dev.projectloader.entity;

import dev.projectloader.model.EntityDefinition;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.world.World;

/**
 * Shared runtime class for JSON-defined entities. It deliberately has no goals and has AI disabled;
 * JSON entities are passive test/display entities until a future behavior system is added.
 */
public final class ProjectEntity extends PathAwareEntity implements GeoEntity {
    private final EntityDefinition definition;
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    public ProjectEntity(EntityType<? extends ProjectEntity> entityType, World world, EntityDefinition definition) {
        super(entityType, world);
        this.definition = definition;
        setAiDisabled(true);
    }

    public EntityDefinition getDefinition() {
        return definition;
    }

    @Override
    protected void initGoals() {
        // Intentionally empty: no goals, target selectors or custom AI are installed.
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String animationName = definition.client().defaultAnimationName();
        controllers.add(new AnimationController<>(this, "project_default", 0,
                state -> state.setAndContinue(RawAnimation.begin().thenLoop(animationName))));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }
}
