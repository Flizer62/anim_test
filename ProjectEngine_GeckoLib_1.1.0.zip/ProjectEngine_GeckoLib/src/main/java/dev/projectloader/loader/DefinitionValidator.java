package dev.projectloader.loader;

import dev.projectloader.component.ComponentContext;
import dev.projectloader.component.ComponentSystem;
import dev.projectloader.component.DefinitionException;
import dev.projectloader.model.ItemDefinition;
import dev.projectloader.util.ProjectPaths;

import java.io.IOException;
import java.nio.file.Path;

/** Parses one item JSON file and validates its schema and components. */
public final class DefinitionValidator {
    private final ComponentSystem componentSystem;
    private final ProjectPaths paths;

    public DefinitionValidator(ComponentSystem componentSystem, ProjectPaths paths) {
        this.componentSystem = componentSystem;
        this.paths = paths;
    }

    public ItemDefinition parseAndValidate(Path file) throws IOException, DefinitionException {
        RawDefinition raw = RawDefinition.read(file);

        ComponentContext context = new ComponentContext();
        componentSystem.applyAll(raw.components(), context);

        return new ItemDefinition(raw.id(), raw.name(), context.toComponents(), file);
    }
}
