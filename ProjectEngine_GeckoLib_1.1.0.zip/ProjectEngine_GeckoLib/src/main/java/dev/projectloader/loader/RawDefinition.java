package dev.projectloader.loader;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.projectloader.component.DefinitionException;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The part of a definition file that is identical for every content type:
 * {@code id}, {@code name} and the raw {@code components} object. Component values are
 * interpreted later by the content type's own component system.
 */
public record RawDefinition(Identifier id, String name, Map<String, JsonElement> components) {

    public static RawDefinition read(Path file) throws IOException, DefinitionException {
        JsonElement parsed;
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            parsed = JsonParser.parseReader(reader);
        } catch (RuntimeException exception) {
            throw new DefinitionException("invalid JSON: " + exception.getMessage(), exception);
        }

        if (!parsed.isJsonObject()) {
            throw new DefinitionException("root JSON value must be an object");
        }

        JsonObject root = parsed.getAsJsonObject();
        String rawId = readRequiredString(root, "id");
        Identifier id = Identifier.tryParse(rawId);
        if (id == null) {
            throw new DefinitionException("id must be a valid namespaced identifier, e.g. project:my_content");
        }

        String name = readRequiredString(root, "name");
        if (name.length() > 128) {
            throw new DefinitionException("name must not exceed 128 characters");
        }

        Map<String, JsonElement> componentValues = new LinkedHashMap<>();
        if (root.has("components")) {
            JsonElement componentsElement = root.get("components");
            if (componentsElement == null || !componentsElement.isJsonObject()) {
                throw new DefinitionException("components must be a JSON object");
            }
            for (Map.Entry<String, JsonElement> entry : componentsElement.getAsJsonObject().entrySet()) {
                componentValues.put(entry.getKey(), entry.getValue());
            }
        }

        return new RawDefinition(id, name, componentValues);
    }

    private static String readRequiredString(JsonObject object, String key) throws DefinitionException {
        JsonElement value = object.get(key);
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new DefinitionException("'" + key + "' must be a non-empty string");
        }

        String string = value.getAsString().trim();
        if (string.isEmpty()) {
            throw new DefinitionException("'" + key + "' must be a non-empty string");
        }
        return string;
    }
}
