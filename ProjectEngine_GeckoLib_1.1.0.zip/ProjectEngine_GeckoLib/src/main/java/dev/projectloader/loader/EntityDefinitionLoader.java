package dev.projectloader.loader;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.projectloader.component.DefinitionException;
import dev.projectloader.model.EntityClientDefinition;
import dev.projectloader.model.EntityDefinition;
import dev.projectloader.util.ProjectPaths;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/** Loads and pairs the two side-specific JSON files for every entity. */
public final class EntityDefinitionLoader {
    private static final double MIN_HEALTH = 0.1;
    private static final double MAX_HEALTH = 2048.0;
    private static final double MIN_HITBOX = 0.1;
    private static final double MAX_HITBOX = 16.0;

    private final ProjectPaths paths;
    private final Logger logger;

    public EntityDefinitionLoader(ProjectPaths paths, Logger logger) {
        this.paths = paths;
        this.logger = logger;
    }

    public List<EntityDefinition> load() {
        Map<Identifier, EntityPair> pairs = new HashMap<>();
        Path directory = paths.entitiesDirectory();

        if (!Files.isDirectory(directory)) {
            logger.warn("Entity directory does not exist: {}", directory);
            return List.of();
        }

        try (Stream<Path> files = Files.walk(directory)) {
            files.filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".json"))
                    .sorted(Comparator.comparing(Path::toString))
                    .forEach(file -> readOne(file, pairs));
        } catch (IOException exception) {
            logger.error("Could not scan entity directory {}: {}", directory, exception.getMessage());
        }

        List<EntityDefinition> definitions = new ArrayList<>();
        pairs.entrySet().stream()
                .sorted(Map.Entry.comparingByKey(Comparator.comparing(Identifier::toString)))
                .forEach(entry -> {
                    EntityPair pair = entry.getValue();
                    if (pair.invalidReason != null) {
                        logger.error("Skipping entity '{}': {}", entry.getKey(), pair.invalidReason);
                    } else if (pair.server == null || pair.client == null) {
                        logger.error("Skipping entity '{}': both <name>_server.json and <name>_client.json are required", entry.getKey());
                    } else {
                        definitions.add(new EntityDefinition(
                                entry.getKey(),
                                pair.server.health,
                                pair.server.hitboxWidth,
                                pair.server.hitboxHeight,
                                pair.client,
                                pair.server.source,
                                pair.clientSource
                        ));
                    }
                });

        logger.info("Loaded {} complete JSON entity definition(s)", definitions.size());
        return definitions;
    }

    private void readOne(Path file, Map<Identifier, EntityPair> pairs) {
        try {
            JsonObject root = readRoot(file);
            Identifier id = readIdentifier(root, "id");
            String side = readString(root, "side").toLowerCase(Locale.ROOT);
            String filename = file.getFileName().toString().toLowerCase(Locale.ROOT);

            boolean serverFile = filename.endsWith("_server.json");
            boolean clientFile = filename.endsWith("_client.json");
            if (!serverFile && !clientFile) {
                throw new DefinitionException("file name must end with _server.json or _client.json");
            }
            if ((serverFile && !side.equals("server")) || (clientFile && !side.equals("client"))) {
                throw new DefinitionException("the side value must match the file suffix (_server or _client)");
            }
            if (!side.equals("server") && !side.equals("client")) {
                throw new DefinitionException("side must be either 'server' or 'client'");
            }

            EntityPair pair = pairs.computeIfAbsent(id, ignored -> new EntityPair());
            if (pair.invalidReason != null) {
                return;
            }

            if (side.equals("server")) {
                if (pair.server != null) {
                    pair.invalidReason = "more than one server-side file uses this id";
                    return;
                }
                pair.server = parseServer(root, file);
            } else {
                if (pair.client != null) {
                    pair.invalidReason = "more than one client-side file uses this id";
                    return;
                }
                ClientParseResult client = parseClient(root, file);
                pair.client = client.definition;
                pair.clientSource = file;
            }
        } catch (IOException | DefinitionException | RuntimeException exception) {
            logger.error("Skipping invalid entity definition {}: {}", file, exception.getMessage());
        }
    }

    private ServerDefinition parseServer(JsonObject root, Path file) throws DefinitionException {
        requireOnlyKeys(root, "id", "side", "health", "hitbox");
        double health = readNumber(root, "health");
        if (health < MIN_HEALTH || health > MAX_HEALTH) {
            throw new DefinitionException("health must be between " + MIN_HEALTH + " and " + MAX_HEALTH);
        }

        JsonElement hitboxElement = root.get("hitbox");
        if (hitboxElement == null || !hitboxElement.isJsonObject()) {
            throw new DefinitionException("hitbox must be an object with width and height numbers");
        }
        JsonObject hitbox = hitboxElement.getAsJsonObject();
        requireOnlyKeys(hitbox, "width", "height");
        double width = readNumber(hitbox, "width");
        double height = readNumber(hitbox, "height");
        if (width < MIN_HITBOX || width > MAX_HITBOX) {
            throw new DefinitionException("hitbox.width must be between " + MIN_HITBOX + " and " + MAX_HITBOX);
        }
        if (height < MIN_HITBOX || height > MAX_HITBOX) {
            throw new DefinitionException("hitbox.height must be between " + MIN_HITBOX + " and " + MAX_HITBOX);
        }

        return new ServerDefinition(health, (float) width, (float) height, file);
    }

    private ClientParseResult parseClient(JsonObject root, Path file) throws IOException, DefinitionException {
        requireOnlyKeys(root, "id", "side", "geometry", "texture", "animation");
        Identifier geometryId = readIdentifier(root, "geometry");
        Identifier animationId = readIdentifier(root, "animation");
        String texturePath = readString(root, "texture");

        Path geometryFile = paths.resolveGeometryFile(geometryId);
        Path animationFile = paths.resolveAnimationFile(animationId);
        Path textureFile = paths.resolveTextureFile(texturePath);

        JsonObject geometryRoot = readRoot(geometryFile);
        JsonElement geometryElement = geometryRoot.get("minecraft:geometry");
        if (geometryElement == null || !geometryElement.isJsonArray() || geometryElement.getAsJsonArray().isEmpty()) {
            throw new DefinitionException("geometry file must contain a non-empty 'minecraft:geometry' array: " + geometryFile);
        }

        JsonObject animationRoot = readRoot(animationFile);
        JsonElement animationsElement = animationRoot.get("animations");
        if (animationsElement == null || !animationsElement.isJsonObject() || animationsElement.getAsJsonObject().entrySet().isEmpty()) {
            throw new DefinitionException("animation file must contain a non-empty 'animations' object: " + animationFile);
        }
        String defaultAnimationName = animationsElement.getAsJsonObject().keySet().stream()
                .min(Comparator.naturalOrder())
                .orElseThrow(() -> new DefinitionException("animation file has no named animations: " + animationFile));
        if (defaultAnimationName.isBlank()) {
            throw new DefinitionException("the default animation name in " + animationFile + " is empty");
        }

        // Read the PNG header now so a missing or corrupt texture is reported against this JSON file.
        dev.projectloader.util.PngHeader.read(textureFile);

        return new ClientParseResult(new EntityClientDefinition(
                geometryId,
                animationId,
                texturePath,
                defaultAnimationName
        ));
    }

    private static JsonObject readRoot(Path file) throws IOException, DefinitionException {
        JsonElement parsed;
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            parsed = JsonParser.parseReader(reader);
        } catch (RuntimeException exception) {
            throw new DefinitionException("invalid JSON in " + file + ": " + exception.getMessage(), exception);
        }
        if (parsed == null || !parsed.isJsonObject()) {
            throw new DefinitionException("JSON root must be an object: " + file);
        }
        return parsed.getAsJsonObject();
    }

    private static Identifier readIdentifier(JsonObject object, String key) throws DefinitionException {
        String value = readString(object, key);
        if (!value.contains(":")) {
            throw new DefinitionException("'" + key + "' must be namespaced, e.g. project:demo_cube");
        }
        Identifier identifier = Identifier.tryParse(value);
        if (identifier == null) {
            throw new DefinitionException("'" + key + "' is not a valid namespaced identifier: " + value);
        }
        return identifier;
    }

    private static String readString(JsonObject object, String key) throws DefinitionException {
        JsonElement value = object.get(key);
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new DefinitionException("'" + key + "' must be a non-empty string");
        }
        String result = value.getAsString().trim();
        if (result.isEmpty()) {
            throw new DefinitionException("'" + key + "' must be a non-empty string");
        }
        return result;
    }

    private static double readNumber(JsonObject object, String key) throws DefinitionException {
        JsonElement value = object.get(key);
        if (value == null || !value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new DefinitionException("'" + key + "' must be a number");
        }
        double result;
        try {
            result = value.getAsDouble();
        } catch (NumberFormatException exception) {
            throw new DefinitionException("'" + key + "' must be a finite number", exception);
        }
        if (!Double.isFinite(result)) {
            throw new DefinitionException("'" + key + "' must be a finite number");
        }
        return result;
    }

    private static void requireOnlyKeys(JsonObject object, String... allowed) throws DefinitionException {
        for (String key : object.keySet()) {
            boolean found = false;
            for (String allowedKey : allowed) {
                if (allowedKey.equals(key)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                throw new DefinitionException("unknown field '" + key + "'");
            }
        }
    }

    private static final class EntityPair {
        private ServerDefinition server;
        private EntityClientDefinition client;
        private Path clientSource;
        private String invalidReason;
    }

    private record ServerDefinition(double health, float hitboxWidth, float hitboxHeight, Path source) {
    }

    private record ClientParseResult(EntityClientDefinition definition) {
    }
}
