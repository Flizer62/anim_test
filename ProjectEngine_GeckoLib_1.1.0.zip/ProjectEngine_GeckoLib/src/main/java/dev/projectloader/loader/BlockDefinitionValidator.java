package dev.projectloader.loader;

import dev.projectloader.component.BlockComponentContext;
import dev.projectloader.component.BlockComponentSystem;
import dev.projectloader.component.DefinitionException;
import dev.projectloader.model.BlockComponents;
import dev.projectloader.model.BlockDefinition;
import dev.projectloader.util.PngHeader;
import dev.projectloader.util.ProjectPaths;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Path;

/** Parses one block JSON file and validates its schema, components and texture. */
public final class BlockDefinitionValidator {
    private final BlockComponentSystem componentSystem;
    private final ProjectPaths paths;
    private final Logger logger;

    public BlockDefinitionValidator(BlockComponentSystem componentSystem, ProjectPaths paths, Logger logger) {
        this.componentSystem = componentSystem;
        this.paths = paths;
        this.logger = logger;
    }

    public BlockDefinition parseAndValidate(Path file) throws IOException, DefinitionException {
        RawDefinition raw = RawDefinition.read(file);

        BlockComponentContext context = new BlockComponentContext();
        componentSystem.applyAll(raw.components(), context);
        BlockComponents components = context.toComponents();

        if (components.texturePath() == null) {
            throw new DefinitionException("components.texture is required for blocks");
        }
        checkTextureSize(raw, components.texturePath());

        return new BlockDefinition(raw.id(), raw.name(), components, file);
    }

    /** Block faces need a square image; 16x16 is the vanilla size and anything else only gets a warning. */
    private void checkTextureSize(RawDefinition raw, String texturePath) throws IOException, DefinitionException {
        PngHeader header;
        try {
            header = PngHeader.read(paths.resolveTextureFile(texturePath));
        } catch (IOException exception) {
            throw new DefinitionException("Invalid components.texture: " + exception.getMessage(), exception);
        }

        if (header.width() != header.height()) {
            throw new DefinitionException("components.texture must be square, but " + texturePath
                    + " is " + header.width() + "x" + header.height());
        }
        if (header.width() != 16) {
            logger.warn("Block '{}': texture {} is {}x{} (vanilla blocks use 16x16)",
                    raw.id(), texturePath, header.width(), header.height());
        }
    }
}
