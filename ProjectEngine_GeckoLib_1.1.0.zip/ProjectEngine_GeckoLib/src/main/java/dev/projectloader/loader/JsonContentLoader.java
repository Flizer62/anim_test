package dev.projectloader.loader;

import dev.projectloader.component.DefinitionException;
import dev.projectloader.model.BlockDefinition;
import dev.projectloader.model.ItemDefinition;
import dev.projectloader.util.ProjectPaths;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Stream;

/** Scans Project/items and Project/blocks recursively and isolates errors to individual files. */
public final class JsonContentLoader {
    private final ProjectPaths paths;
    private final DefinitionValidator itemValidator;
    private final BlockDefinitionValidator blockValidator;
    private final Logger logger;

    public JsonContentLoader(ProjectPaths paths,
                             DefinitionValidator itemValidator,
                             BlockDefinitionValidator blockValidator,
                             Logger logger) {
        this.paths = paths;
        this.itemValidator = itemValidator;
        this.blockValidator = blockValidator;
        this.logger = logger;
    }

    public List<ItemDefinition> loadItems() {
        return scan(paths.itemsDirectory(), "item", itemValidator::parseAndValidate, ItemDefinition::id);
    }

    public List<BlockDefinition> loadBlocks() {
        return scan(paths.blocksDirectory(), "block", blockValidator::parseAndValidate, BlockDefinition::id);
    }

    @FunctionalInterface
    private interface DefinitionParser<T> {
        T parse(Path file) throws IOException, DefinitionException;
    }

    private <T> List<T> scan(Path directory, String kind, DefinitionParser<T> parser, Function<T, Identifier> idOf) {
        List<T> definitions = new ArrayList<>();
        Set<Identifier> seenIds = new HashSet<>();

        if (!Files.isDirectory(directory)) {
            logger.warn("{} directory does not exist: {}", kind, directory);
            return definitions;
        }

        try (Stream<Path> files = Files.walk(directory)) {
            files.filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().toLowerCase().endsWith(".json"))
                    .sorted(Comparator.comparing(Path::toString))
                    .forEach(file -> {
                        try {
                            T definition = parser.parse(file);
                            Identifier id = idOf.apply(definition);
                            if (!seenIds.add(id)) {
                                logger.warn("Skipping duplicate {} id '{}' in {}", kind, id, file);
                                return;
                            }
                            definitions.add(definition);
                        } catch (IOException | DefinitionException | RuntimeException exception) {
                            logger.error("Skipping invalid {} definition {}: {}", kind, file, exception.getMessage());
                        }
                    });
        } catch (IOException exception) {
            logger.error("Could not scan {} directory {}: {}", kind, directory, exception.getMessage());
        }

        logger.info("Loaded {} valid JSON {} definition(s)", definitions.size(), kind);
        return definitions;
    }
}
