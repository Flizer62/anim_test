package dev.projectloader.factory;

import dev.projectloader.entity.ProjectEntity;
import dev.projectloader.model.EntityDefinition;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/** Creates the native Minecraft entity type for a validated JSON entity definition. */
public final class EntityFactory {
    public EntityType<ProjectEntity> create(EntityDefinition definition) {
        EntityType<ProjectEntity> type = EntityType.Builder
                .create((entityType, world) -> new ProjectEntity(entityType, world, definition), SpawnGroup.MISC)
                .dimensions(definition.hitboxWidth(), definition.hitboxHeight())
                .maxTrackingRange(10)
                .trackingTickInterval(3)
                .build(definition.id().toString());

        Registry.register(Registries.ENTITY_TYPE, definition.id(), type);
        return type;
    }
}
