package dev.projectloader.factory;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContextParameterSet;

import java.util.List;

/**
 * Block created from a JSON definition. Loot tables are data-pack files, which a JSON-only block has none of,
 * so the block simply drops its own item when broken.
 */
public final class ProjectBlock extends Block {
    public ProjectBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public List<ItemStack> getDroppedStacks(BlockState state, LootContextParameterSet.Builder builder) {
        return List.of(new ItemStack(this));
    }
}
