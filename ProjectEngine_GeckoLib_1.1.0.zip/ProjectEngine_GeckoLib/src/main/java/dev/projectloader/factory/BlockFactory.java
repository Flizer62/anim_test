package dev.projectloader.factory;

import dev.projectloader.model.BlockComponents;
import dev.projectloader.model.BlockDefinition;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Converts a validated JSON block definition into a real Minecraft Block and its BlockItem. */
public final class BlockFactory {
    /**
     * Vanilla survival mining: with a bare hand on a block that does not require a tool, one point of hardness
     * takes 30 ticks, i.e. 1.5 seconds. {@code break_time} is converted with this factor.
     */
    public static final double SECONDS_PER_HARDNESS = 1.5;

    /** Used when a block does not specify {@code break_time} (hardness 1.0). */
    public static final double DEFAULT_BREAK_TIME = 1.5;

    /** Sound group the optional sounds are layered on top of: stone, for step, hit and fall sounds too. */
    private static final BlockSoundGroup DEFAULT_SOUNDS = BlockSoundGroup.STONE;

    public Block create(BlockDefinition definition) {
        BlockComponents components = definition.components();

        double breakTime = components.breakTime() != null ? components.breakTime() : DEFAULT_BREAK_TIME;
        float hardness = (float) (breakTime / SECONDS_PER_HARDNESS);

        AbstractBlock.Settings settings = AbstractBlock.Settings.create()
                .strength(hardness)
                .sounds(soundGroup(components));

        return new ProjectBlock(settings);
    }

    public BlockItem createItem(Block block) {
        return new BlockItem(block, new Item.Settings());
    }

    /**
     * Vanilla plays the place and break sounds of a block's sound group, so the JSON sounds are applied by
     * building a custom group. Anything that is not specified keeps the stone sound.
     */
    private static BlockSoundGroup soundGroup(BlockComponents components) {
        if (components.placeSound() == null && components.breakSound() == null) {
            return DEFAULT_SOUNDS;
        }

        SoundEvent placeSound = components.placeSound() != null
                ? resolve(components.placeSound())
                : DEFAULT_SOUNDS.getPlaceSound();
        SoundEvent breakSound = components.breakSound() != null
                ? resolve(components.breakSound())
                : DEFAULT_SOUNDS.getBreakSound();

        return new BlockSoundGroup(
                DEFAULT_SOUNDS.getVolume(),
                DEFAULT_SOUNDS.getPitch(),
                breakSound,
                DEFAULT_SOUNDS.getStepSound(),
                placeSound,
                DEFAULT_SOUNDS.getHitSound(),
                DEFAULT_SOUNDS.getFallSound()
        );
    }

    /** Uses the registered sound event when there is one, otherwise a bare event with that id (e.g. from a resource pack). */
    private static SoundEvent resolve(Identifier id) {
        return Registries.SOUND_EVENT.getOrEmpty(id).orElseGet(() -> SoundEvent.of(id));
    }
}
