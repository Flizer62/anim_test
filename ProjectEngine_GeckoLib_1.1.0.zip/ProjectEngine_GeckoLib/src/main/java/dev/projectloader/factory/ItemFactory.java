package dev.projectloader.factory;

import dev.projectloader.model.ItemDefinition;
import dev.projectloader.model.ItemComponents;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;

/** Converts a validated JSON item definition into a real Minecraft Item. */
public final class ItemFactory {
    public Item create(ItemDefinition definition) {
        ItemComponents components = definition.components();
        Item.Settings settings = new Item.Settings();

        // Items that define combat attributes behave like weapons and do not stack.
        settings.maxCount(components.hasCombatAttributes() ? 1 : 64);

        AttributeModifiersComponent modifiers = AttributeModifiersComponent.DEFAULT;
        boolean hasModifiers = false;

        if (components.damage() != null) {
            // Player base attack damage is 1.0; JSON damage means the final target value.
            double modifierValue = components.damage() - 1.0;
            Identifier modifierId = modifierId(definition.id(), "attack_damage");
            modifiers = modifiers.with(
                    EntityAttributes.GENERIC_ATTACK_DAMAGE,
                    new EntityAttributeModifier(modifierId, modifierValue, EntityAttributeModifier.Operation.ADD_VALUE),
                    AttributeModifierSlot.MAINHAND
            );
            hasModifiers = true;
        }

        if (components.attackSpeed() != null) {
            // Player base attack speed is 4.0; JSON attack_speed means the final target value.
            double modifierValue = components.attackSpeed() - 4.0;
            Identifier modifierId = modifierId(definition.id(), "attack_speed");
            modifiers = modifiers.with(
                    EntityAttributes.GENERIC_ATTACK_SPEED,
                    new EntityAttributeModifier(modifierId, modifierValue, EntityAttributeModifier.Operation.ADD_VALUE),
                    AttributeModifierSlot.MAINHAND
            );
            hasModifiers = true;
        }

        if (hasModifiers) {
            settings.attributeModifiers(modifiers);
        }

        return new Item(settings);
    }

    private static Identifier modifierId(Identifier itemId, String component) {
        String path = itemId.getNamespace() + "/" + itemId.getPath() + "/" + component;
        return Identifier.of("project_content_loader", path);
    }
}
