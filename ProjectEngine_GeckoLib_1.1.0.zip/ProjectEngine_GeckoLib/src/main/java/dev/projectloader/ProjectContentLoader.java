package dev.projectloader;

import dev.projectloader.component.BlockComponentSystem;
import dev.projectloader.component.ComponentSystem;
import dev.projectloader.factory.BlockFactory;
import dev.projectloader.factory.EntityFactory;
import dev.projectloader.factory.ItemFactory;
import dev.projectloader.loader.BlockDefinitionValidator;
import dev.projectloader.loader.DefinitionValidator;
import dev.projectloader.loader.EntityDefinitionLoader;
import dev.projectloader.loader.JsonContentLoader;
import dev.projectloader.model.BlockDefinition;
import dev.projectloader.model.EntityDefinition;
import dev.projectloader.model.ItemDefinition;
import dev.projectloader.registry.ContentRegistry;
import dev.projectloader.registry.EntityContentRegistry;
import dev.projectloader.registry.RegisteredBlock;
import dev.projectloader.registry.RegisteredEntity;
import dev.projectloader.registry.RegisteredItem;
import dev.projectloader.texture.TextureLoader;
import dev.projectloader.util.ProjectPaths;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

public final class ProjectContentLoader implements ModInitializer {
    public static final String MOD_ID = "project_content_loader";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Read-only snapshot used by the client initializer to register the GeckoLib renderers. */
    public static List<RegisteredEntity> REGISTERED_ENTITIES = List.of();

    @Override
    public void onInitialize() {
        ProjectPaths paths = new ProjectPaths();

        try {
            paths.createDirectories();
        } catch (IOException exception) {
            LOGGER.error("Could not create external Project/ directories: {}", exception.getMessage());
            return;
        }

        DefinitionValidator itemValidator = new DefinitionValidator(new ComponentSystem(paths), paths);
        BlockDefinitionValidator blockValidator =
                new BlockDefinitionValidator(new BlockComponentSystem(paths), paths, LOGGER);
        JsonContentLoader contentLoader = new JsonContentLoader(paths, itemValidator, blockValidator, LOGGER);
        List<ItemDefinition> itemDefinitions = contentLoader.loadItems();
        List<BlockDefinition> blockDefinitions = contentLoader.loadBlocks();
        List<EntityDefinition> entityDefinitions = new EntityDefinitionLoader(paths, LOGGER).load();

        // Items first: a block's BlockItem shares its id, so an item clash is detected when registering blocks.
        ContentRegistry registry = new ContentRegistry(new ItemFactory(), new BlockFactory(), LOGGER);
        List<RegisteredItem> registeredItems = registry.registerItems(itemDefinitions);
        List<RegisteredBlock> registeredBlocks = registry.registerBlocks(blockDefinitions);

        // Entity registration is separate from item/block registration by design.
        REGISTERED_ENTITIES = new EntityContentRegistry(new EntityFactory(), LOGGER).registerEntities(entityDefinitions);

        try {
            new TextureLoader(paths, LOGGER).generateResourcePack(registeredItems, registeredBlocks, REGISTERED_ENTITIES);
        } catch (IOException exception) {
            LOGGER.error("Could not generate the resource pack: {}", exception.getMessage(), exception);
        }

        LOGGER.info("Project Engine finished: {} item(s), {} block(s), {} entity(s) registered",
                registeredItems.size(), registeredBlocks.size(), REGISTERED_ENTITIES.size());
    }
}
