package dev.projectloader.util;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Resolves the user-facing Project/ folder inside the Minecraft game directory. */
public final class ProjectPaths {
    private final Path gameDirectory;
    private final Path projectDirectory;

    public ProjectPaths() {
        this.gameDirectory = FabricLoader.getInstance().getGameDir().toAbsolutePath().normalize();
        this.projectDirectory = gameDirectory.resolve("Project").normalize();
    }

    public Path gameDirectory() {
        return gameDirectory;
    }

    public Path projectDirectory() {
        return projectDirectory;
    }

    public Path itemsDirectory() {
        return projectDirectory.resolve("items");
    }

    public Path blocksDirectory() {
        return projectDirectory.resolve("blocks");
    }

    public Path texturesDirectory() {
        return projectDirectory.resolve("textures");
    }

    public Path entitiesDirectory() {
        return projectDirectory.resolve("entity");
    }

    public Path geometryDirectory() {
        return projectDirectory.resolve("geometry");
    }

    public Path animationsDirectory() {
        return projectDirectory.resolve("animations");
    }

    /** Creates the external content directories without bundling or overwriting user content. */
    public void createDirectories() throws IOException {
        Files.createDirectories(itemsDirectory());
        Files.createDirectories(texturesDirectory());
        Files.createDirectories(entitiesDirectory());
        Files.createDirectories(geometryDirectory());
        Files.createDirectories(animationsDirectory());
        Files.createDirectories(texturesDirectory().resolve("entity"));
        Files.createDirectories(blocksDirectory());
    }


    /** Resolves a namespaced geometry id to Project/geometry/<path>.geo.json. */
    public Path resolveGeometryFile(net.minecraft.util.Identifier id) throws IOException {
        return resolveNamedAsset(geometryDirectory(), id, ".geo.json", "geometry");
    }

    /** Resolves a namespaced animation id to Project/animations/<path>.animation.json. */
    public Path resolveAnimationFile(net.minecraft.util.Identifier id) throws IOException {
        return resolveNamedAsset(animationsDirectory(), id, ".animation.json", "animation");
    }

    private Path resolveNamedAsset(Path baseDirectory, net.minecraft.util.Identifier id, String suffix, String label) throws IOException {
        Path relative = Path.of(id.getPath() + suffix).normalize();
        if (relative.isAbsolute() || relative.startsWith("..")) {
            throw new IOException(label + " id escapes its Project directory");
        }
        Path resolved = baseDirectory.resolve(relative).normalize();
        if (!resolved.startsWith(baseDirectory.normalize())) {
            throw new IOException(label + " id escapes its Project directory");
        }
        if (!Files.isRegularFile(resolved)) {
            throw new IOException(label + " file does not exist: " + resolved);
        }
        return resolved;
    }

    /**
     * Resolves either "Project/textures/name.png" or "textures/name.png".
     * Absolute paths and traversal outside Project/ are rejected.
     */
    public Path resolveTextureFile(String input) throws IOException {
        String normalizedSeparators = input.replace('\\', '/').trim();
        Path relative = Path.of(normalizedSeparators);
        if (relative.isAbsolute()) {
            throw new IOException("absolute paths are not allowed");
        }

        relative = relative.normalize();
        if (relative.startsWith("..")) {
            throw new IOException("path traversal is not allowed");
        }

        if (relative.getNameCount() > 0 && relative.getName(0).toString().equalsIgnoreCase("Project")) {
            relative = relative.subpath(1, relative.getNameCount());
        }

        if (relative.getNameCount() < 2 || !relative.getName(0).toString().equalsIgnoreCase("textures")) {
            throw new IOException("texture path must be inside Project/textures/");
        }

        if (!relative.getFileName().toString().toLowerCase().endsWith(".png")) {
            throw new IOException("only PNG textures are supported");
        }

        Path resolved = projectDirectory.resolve(relative).normalize();
        if (!resolved.startsWith(texturesDirectory().normalize())) {
            throw new IOException("texture path escapes Project/textures/");
        }
        if (!Files.isRegularFile(resolved)) {
            throw new IOException("file does not exist: " + resolved);
        }
        return resolved;
    }
}
