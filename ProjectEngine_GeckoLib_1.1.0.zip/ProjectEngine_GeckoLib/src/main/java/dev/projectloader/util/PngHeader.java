package dev.projectloader.util;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Reads PNG dimensions straight from the IHDR chunk, so no image library (java.desktop) is needed. */
public record PngHeader(int width, int height) {
    private static final long SIGNATURE = 0x89504E470D0A1A0AL;
    private static final int IHDR = 0x49484452; // "IHDR"

    public static PngHeader read(Path file) throws IOException {
        try (InputStream raw = Files.newInputStream(file); DataInputStream in = new DataInputStream(raw)) {
            if (in.readLong() != SIGNATURE) {
                throw new IOException("not a valid PNG file");
            }
            in.readInt(); // IHDR chunk length (always 13)
            if (in.readInt() != IHDR) {
                throw new IOException("PNG header chunk is missing");
            }
            int width = in.readInt();
            int height = in.readInt();
            if (width <= 0 || height <= 0) {
                throw new IOException("PNG has invalid dimensions");
            }
            return new PngHeader(width, height);
        } catch (java.io.EOFException exception) {
            throw new IOException("PNG file is truncated", exception);
        }
    }
}
