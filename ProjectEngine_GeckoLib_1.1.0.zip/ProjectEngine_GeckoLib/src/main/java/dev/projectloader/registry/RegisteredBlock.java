package dev.projectloader.registry;

import dev.projectloader.model.BlockDefinition;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;

public record RegisteredBlock(BlockDefinition definition, Block block, BlockItem item) {
}
