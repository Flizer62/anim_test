package dev.projectloader.registry;

import dev.projectloader.factory.EntityFactory;
import dev.projectloader.model.EntityDefinition;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/** Entity-specific registry, kept independent from the item and block systems. */
public final class EntityContentRegistry {
    private final EntityFactory factory;
    private final Logger logger;

    public EntityContentRegistry(EntityFactory factory, Logger logger) {
        this.factory = factory;
        this.logger = logger;
    }

    public List<RegisteredEntity> registerEntities(List<EntityDefinition> definitions) {
        List<RegisteredEntity> registered = new ArrayList<>();

        for (EntityDefinition definition : definitions) {
            if (Registries.ENTITY_TYPE.containsId(definition.id())) {
                logger.warn("Skipping entity '{}' because that entity type id is already registered", definition.id());
                continue;
            }

            try {
                EntityType<dev.projectloader.entity.ProjectEntity> type = factory.create(definition);
                FabricDefaultAttributeRegistry.register(type, MobEntity.createMobAttributes()
                        .add(EntityAttributes.GENERIC_MAX_HEALTH, definition.health())
                        .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0));
                registered.add(new RegisteredEntity(definition, type));
                logger.info("Registered entity '{}' (health {}, hitbox {}x{})",
                        definition.id(), definition.health(), definition.hitboxWidth(), definition.hitboxHeight());
            } catch (RuntimeException exception) {
                logger.error("Could not register entity '{}': {}", definition.id(), exception.getMessage(), exception);
            }
        }

        return List.copyOf(registered);
    }
}
