package dev.projectloader.registry;

import dev.projectloader.factory.BlockFactory;
import dev.projectloader.factory.ItemFactory;
import dev.projectloader.model.BlockDefinition;
import dev.projectloader.model.ItemDefinition;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/** Owns Minecraft registry writes for items and blocks; entities use their independent registry. */
public final class ContentRegistry {
    private final ItemFactory itemFactory;
    private final BlockFactory blockFactory;
    private final Logger logger;

    public ContentRegistry(ItemFactory itemFactory, BlockFactory blockFactory, Logger logger) {
        this.itemFactory = itemFactory;
        this.blockFactory = blockFactory;
        this.logger = logger;
    }

    public List<RegisteredItem> registerItems(List<ItemDefinition> definitions) {
        List<RegisteredItem> registered = new ArrayList<>();

        for (ItemDefinition definition : definitions) {
            if (Registries.ITEM.containsId(definition.id())) {
                logger.warn("Skipping '{}' because that item id is already registered", definition.id());
                continue;
            }

            try {
                Item item = itemFactory.create(definition);
                Registry.register(Registries.ITEM, definition.id(), item);
                registered.add(new RegisteredItem(definition, item));
                logger.info("Registered item '{}' ({})", definition.displayName(), definition.id());
            } catch (RuntimeException exception) {
                logger.error("Could not register item '{}': {}", definition.id(), exception.getMessage());
            }
        }

        return registered;
    }

    /**
     * Registers each block together with its BlockItem (same id). Call after {@link #registerItems} so an id
     * that is already taken by a JSON item is detected here.
     */
    public List<RegisteredBlock> registerBlocks(List<BlockDefinition> definitions) {
        List<RegisteredBlock> registered = new ArrayList<>();

        for (BlockDefinition definition : definitions) {
            if (Registries.BLOCK.containsId(definition.id()) || Registries.ITEM.containsId(definition.id())) {
                logger.warn("Skipping block '{}' because that id is already registered as a block or an item", definition.id());
                continue;
            }

            try {
                Block block = blockFactory.create(definition);
                BlockItem item = blockFactory.createItem(block);
                Registry.register(Registries.BLOCK, definition.id(), block);
                Registry.register(Registries.ITEM, definition.id(), item);
                registered.add(new RegisteredBlock(definition, block, item));
                logger.info("Registered block '{}' ({})", definition.displayName(), definition.id());
            } catch (RuntimeException exception) {
                logger.error("Could not register block '{}': {}", definition.id(), exception.getMessage());
            }
        }

        return registered;
    }
}
