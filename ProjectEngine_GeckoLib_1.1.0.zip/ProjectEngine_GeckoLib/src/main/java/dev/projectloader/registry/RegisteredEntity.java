package dev.projectloader.registry;

import dev.projectloader.entity.ProjectEntity;
import dev.projectloader.model.EntityDefinition;
import net.minecraft.entity.EntityType;

public record RegisteredEntity(EntityDefinition definition, EntityType<ProjectEntity> entityType) {
}
