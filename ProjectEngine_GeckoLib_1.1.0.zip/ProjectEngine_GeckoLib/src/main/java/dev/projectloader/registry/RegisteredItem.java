package dev.projectloader.registry;

import dev.projectloader.model.ItemDefinition;
import net.minecraft.item.Item;

public record RegisteredItem(ItemDefinition definition, Item item) {
}
